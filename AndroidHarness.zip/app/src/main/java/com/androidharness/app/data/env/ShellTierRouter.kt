package com.androidharness.app.data.env

import android.content.Context
import com.androidharness.app.tools.ShellPolicy
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.TimeUnit

/** Classifies a filesystem path into one of the regions the shell tiers can reach. */
object PathClassifier {
    enum class Region { APP_DATA, SHARED_STORAGE, SYSTEM }

    fun regionOf(path: String, internalDataRoot: String, externalDataRoot: String? = null): Region = when {
        path == internalDataRoot || path.startsWith("$internalDataRoot/") -> Region.APP_DATA
        externalDataRoot != null &&
            (path == externalDataRoot || path.startsWith("$externalDataRoot/")) -> Region.APP_DATA
        path == "/storage/emulated/0" || path.startsWith("/storage/emulated/0/") -> Region.SHARED_STORAGE
        else -> Region.SYSTEM
    }
}

/** Which engine actually runs the shell command. */
enum class ExecutionTier {
    TERMUX_SSH,
    ROOT,
    /** Inside Shizuku's server process: shell/root uid, can reach system paths and any folder. */
    PRIVILEGED,

    /** The app's own uid running the Termux-prefix Linux toolchain (with linker workaround). */
    APP_LINUX,

    /** Bare toybox sh when the app-side toolchain is not installed. */
    TOYBOX,
}

data class ShellRunResult(
    val exitCode: Int,
    val timedOut: Boolean,
    val rawOutput: String,
    val rawStderr: String,
    val tier: ExecutionTier,
    val note: String?,
)

    /**
     * Decides which execution tier runs each shell command, based on where the
     * working directory lives and which privileges are currently available:
     *
     * - App data dir   -> app-uid toolchain (Shizuku's shell uid can't enter it).
     * - Anything else  -> Shizuku (shell uid) when granted: real exec of the
     *   deployed toolchain copy, system paths, any folder. Otherwise the app
     *   uid: on shared storage only with "All files access", on system paths
     *   best-effort with an explanatory note.
     */
class ShellTierRouter(
    private val context: Context,
    private val shizuku: ShizukuManager,
    private val linuxEnv: LinuxEnvironmentManager,
    val deviceAccess: DeviceAccessManager? = null,
) {

    /** Broad shared-storage access, including runtime storage permission on Android 8–10. */
    fun isAllFilesAccess(): Boolean = StorageAccess.isGranted(context)

    fun resolveTier(cwd: File): ExecutionTier {
        val region = regionOf(cwd)
        return when (region) {
            PathClassifier.Region.APP_DATA ->
                if (linuxEnv.isReady) ExecutionTier.APP_LINUX else ExecutionTier.TOYBOX
            PathClassifier.Region.SHARED_STORAGE,
            PathClassifier.Region.SYSTEM -> when {
                // The shell uid can reach both /sdcard and system paths, and the
                // deployed tmp toolchain execs normally, so it's the best tier.
                shizuku.hasPrivilegedAccess() -> ExecutionTier.PRIVILEGED
                isAllFilesAccess() -> if (linuxEnv.isReady) ExecutionTier.APP_LINUX else ExecutionTier.TOYBOX
                else -> if (linuxEnv.isReady) ExecutionTier.APP_LINUX else ExecutionTier.TOYBOX
            }
        }
    }

    /** A user-facing note explaining why the tier may be degraded, if so. */
    fun permissionNote(cwd: File, tier: ExecutionTier): String? {
        val region = regionOf(cwd)
        return when {
            tier == ExecutionTier.APP_LINUX &&
                region == PathClassifier.Region.SHARED_STORAGE &&
                !isAllFilesAccess() ->
                "[note: shared storage access is not granted: expect permission errors here. Grant it in Settings → Storage access, use the app workspace, or connect a privileged shell in Settings → Terminal.]"

            tier == ExecutionTier.TOYBOX &&
                region == PathClassifier.Region.SYSTEM &&
                !shizuku.hasPrivilegedAccess() ->
                "[note: this is a system path the app cannot touch on its own. Start Shizuku or connect Wireless ADB in Settings → Terminal to unlock it.]"

            else -> null
        }
    }

    // The default app workspace is in getExternalFilesDir(), which needs no
    // storage grant and should run as the app user even when Shizuku is available.
    private fun regionOf(cwd: File): PathClassifier.Region = PathClassifier.regionOf(
        cwd.absolutePath,
        linuxEnv.internalDataRoot.absolutePath,
        context.getExternalFilesDir(null)?.absolutePath,
    )

    /** Executes [command] with cwd [cwd] and returns a uniform result. */
    suspend fun run(command: String, cwd: File, timeoutMs: Int, maxOutput: Int): ShellRunResult =
        // Both tiers block for the whole run: they poll the child every 50ms,
        // join the reader threads and, in the privileged tier, make binder
        // calls. Callers include Compose scopes on the main dispatcher, which
        // would freeze the UI for the command's full duration, so the work
        // never inherits the caller's dispatcher.
        withContext(Dispatchers.IO) {
            deviceAccess?.let { access ->
                return@withContext access.execute(
                    appWorkspace = access.pinsAppUser(cwd),
                    normal = { runApp(command, cwd, timeoutMs, maxOutput, if (linuxEnv.isReady) ExecutionTier.APP_LINUX else ExecutionTier.TOYBOX) },
                    shizukuRun = { runPrivileged(command, cwd, timeoutMs, maxOutput, allowFallback = false) },
                    rootRun = { access.runRoot(command, cwd, timeoutMs, maxOutput) },
                )
            }
            when (val tier = resolveTier(cwd)) {
                ExecutionTier.ROOT -> error("Root requires device access routing")
                ExecutionTier.TERMUX_SSH -> error("SSH requires a captured workspace")
                ExecutionTier.PRIVILEGED -> requireNotNull(runPrivileged(command, cwd, timeoutMs, maxOutput))
                ExecutionTier.APP_LINUX -> runApp(command, cwd, timeoutMs, maxOutput, ExecutionTier.APP_LINUX)
                ExecutionTier.TOYBOX -> runApp(command, cwd, timeoutMs, maxOutput, ExecutionTier.TOYBOX)
            }
        }

    suspend fun runWorkspace(command: String, workspace: com.androidharness.app.workspace.WorkspaceFs,
                             timeoutMs: Int, maxOutput: Int): ShellRunResult {
        if (workspace is com.androidharness.app.workspace.SshFs) return workspace.run(command, timeoutMs = timeoutMs, maxOutput = maxOutput)
        return run(command, requireNotNull(workspace.shellRoot) { "This workspace has no shell" }, timeoutMs, maxOutput)
    }

    // --- privileged tier ---------------------------------------------------

    /**
     * Bug 2 fix: provisions the exec-capable scratch dir via the privileged
     * side when Shizuku is available. Best-effort; the app-side init also
     * creates it directly. 0700 shell-owned: every legitimate user (Shizuku
     * exec, adb) runs as the shell uid, and the app uid is walled off from
     * /data/local/tmp by DAC and SELinux anyway.
     */
    private suspend fun ensurePrivilegedScratch() {
        val scratch = ShellPolicy.SCRATCH_TMP
        shizuku.runPrivileged(
            arrayOf(
                "/system/bin/sh",
                "-c",
                "mkdir -p '$scratch' && chmod 700 '$scratch'",
            ),
            env = null,
            dir = null,
            timeoutMs = 10_000,
            maxBytes = 1_000,
        )
    }

    private suspend fun runPrivileged(
        command: String,
        cwd: File,
        timeoutMs: Int,
        maxOutput: Int,
        allowFallback: Boolean = true,
    ): ShellRunResult? {
        // Self-heal: catch a stale or vanished deployed copy even when nothing
        // in-process changed the staging state (throttled internally).
        linuxEnv.verifyDeployedCopyThrottled(shizuku)
        // The deployed copy has to come from the same package set this tier's
        // environment (tmpProcessEnv) is built for. Asking only whether it
        // exists accepts a copy that is missing the libraries the environment
        // names, and every binary started in it then dies in the linker with
        // `CANNOT LINK EXECUTABLE ... library "..." not found`.
        val expectedTag = linuxEnv.deployedTag()
        var toolchain = linuxEnv.isReady && shizuku.isTmpPrefixDeployed(expectedTag)
        if (linuxEnv.isReady && !toolchain) {
            // One-time deploy of the toolchain to an exec-allowed location.
            linuxEnv.ensureShellDeploy(shizuku)
            toolchain = shizuku.isTmpPrefixDeployed(expectedTag)
        }
        // Bug 2 fix: make sure the designated exec-capable scratch dir exists
        // and is writable by both the shell uid and the app uid.
        runCatching { ensurePrivilegedScratch() }

        val cmd = if (toolchain) {
            arrayOf("${linuxEnv.tmpPrefix}/bin/bash", "-c", command)
        } else {
            arrayOf("/system/bin/sh", "-c", command)
        }
        val env = if (toolchain) {
            linuxEnv.tmpProcessEnv().map { "${it.key}=${it.value}" }.toTypedArray()
        } else null

        val r = shizuku.runPrivileged(cmd, env, cwd.absolutePath, timeoutMs, maxOutput)
        if (r == null) {
            if (!allowFallback) return null
            // No dispatch began: fall back to the app uid tier.
            val fb = runApp(command, cwd, timeoutMs, maxOutput, ExecutionTier.APP_LINUX)
            return ShellRunResult(
                exitCode = fb.exitCode,
                timedOut = fb.timedOut,
                rawOutput = fb.rawOutput,
                rawStderr = fb.rawStderr,
                tier = ExecutionTier.APP_LINUX,
                note = "[note: Shizuku's privileged runner was unavailable, so this ran as the app user: expect permission errors on this directory]",
            )
        }
        val note = if (!toolchain) {
            "[note: privileged shell running /system/bin/sh only: install the Linux environment in Settings → Terminal for bash/git/python/node here]"
        } else null
        return ShellRunResult(r.exitCode, r.timedOut, r.output, r.stderr, ExecutionTier.PRIVILEGED, note)
    }

    // --- app-uid tier ------------------------------------------------------

    private suspend fun runApp(
        command: String,
        cwd: File,
        timeoutMs: Int,
        maxOutput: Int,
        tier: ExecutionTier,
    ): ShellRunResult {
        val process = try {
            linuxEnv.startShell(command, cwd).first
        } catch (e: Exception) {
            return ShellRunResult(
                exitCode = -1,
                timedOut = false,
                rawOutput = "Failed to start shell (directory not reachable by the app?): ${e.message}",
                rawStderr = "",
                tier = ExecutionTier.TOYBOX,
                note = permissionNote(cwd, tier),
            )
        }

        val stdout = StringBuffer()
        val stderr = StringBuffer()
        val out = Thread { gobble(process.inputStream, stdout, maxOutput) }
        val err = Thread { gobble(process.errorStream, stderr, maxOutput) }
        listOf(out, err).forEach { it.isDaemon = true; it.start() }

        val deadline = System.currentTimeMillis() + timeoutMs
        var timedOut = false
        var exitCode = -1
        try {
            while (true) {
                currentCoroutineContext().ensureActive()
                if (process.waitFor(50, TimeUnit.MILLISECONDS)) {
                    exitCode = process.exitValue()
                    break
                }
                if (System.currentTimeMillis() > deadline) {
                    timedOut = true
                    break
                }
            }

            val pid = runCatching {
                val f = process.javaClass.getDeclaredField("pid")
                f.isAccessible = true
                f.getInt(process)
            }.getOrNull()
            if (pid != null && pid > 0) {
                if (timedOut) {
                    killGroup(pid)
                    process.destroyForcibly()
                    process.waitFor(200, TimeUnit.MILLISECONDS)
                } else {
                    // Command finished normally: clean up any detached/orphan grandchildren in this process group
                    cleanOrphanGroup(pid)
                }
            }
            reapZombies()

            out.join(300)
            err.join(300)
            reapZombies()

        } finally {
            // Cancellation must terminate the command before RunManager can finish or steer.
            if (process.isAlive) {
                val pid = runCatching {
                    process.javaClass.getDeclaredField("pid").apply { isAccessible = true }.getInt(process)
                }.getOrNull()
                if (pid != null && pid > 0) killGroup(pid)
                runCatching { process.destroyForcibly() }
                runCatching { process.waitFor(200, TimeUnit.MILLISECONDS) }
            }
            runCatching { process.inputStream.close() }
            runCatching { process.errorStream.close() }
            runCatching { process.outputStream.close() }
        }

        return ShellRunResult(
            exitCode,
            timedOut,
            stdout.toString(),
            stderr.toString(),
            tier,
            permissionNote(cwd, tier),
        )
    }

    private fun gobble(stream: java.io.InputStream, into: StringBuffer, max: Int) {
        try {
            val buf = CharArray(4096)
            stream.bufferedReader().use { reader ->
                while (true) {
                    val n = reader.read(buf)
                    if (n <= 0) break
                    synchronized(into) {
                        if (into.length < max) {
                            val toAppend = minOf(n, max - into.length)
                            into.append(buf, 0, toAppend)
                        }
                    }
                }
            }
        } catch (_: Exception) {
        }
    }

    private fun killGroup(pid: Int) {
        runCatching { android.system.Os.kill(-pid, android.system.OsConstants.SIGKILL) }
        val killBin = if (File("/system/bin/kill").exists()) "/system/bin/kill" else "kill"
        runCatching {
            val k = Runtime.getRuntime().exec(arrayOf(killBin, "-9", "-$pid"))
            k.waitFor(100, TimeUnit.MILLISECONDS)
        }
        val pkillBin = if (File("/system/bin/pkill").exists()) "/system/bin/pkill" else "pkill"
        runCatching {
            val pkillS = Runtime.getRuntime().exec(arrayOf(pkillBin, "-9", "-s", pid.toString()))
            pkillS.waitFor(100, TimeUnit.MILLISECONDS)
        }
        runCatching {
            val pkillP = Runtime.getRuntime().exec(arrayOf(pkillBin, "-9", "-P", pid.toString()))
            pkillP.waitFor(100, TimeUnit.MILLISECONDS)
        }
        runCatching { android.system.Os.kill(pid, android.system.OsConstants.SIGKILL) }
        runCatching {
            val k = Runtime.getRuntime().exec(arrayOf(killBin, "-9", pid.toString()))
            k.waitFor(100, TimeUnit.MILLISECONDS)
        }
    }

    private fun cleanOrphanGroup(pid: Int) {
        runCatching { android.system.Os.kill(-pid, android.system.OsConstants.SIGKILL) }
        val killBin = if (File("/system/bin/kill").exists()) "/system/bin/kill" else "kill"
        runCatching {
            val k = Runtime.getRuntime().exec(arrayOf(killBin, "-9", "-$pid"))
            k.waitFor(100, TimeUnit.MILLISECONDS)
        }
        val pkillBin = if (File("/system/bin/pkill").exists()) "/system/bin/pkill" else "pkill"
        runCatching {
            val pkillS = Runtime.getRuntime().exec(arrayOf(pkillBin, "-9", "-s", pid.toString()))
            pkillS.waitFor(100, TimeUnit.MILLISECONDS)
        }
    }

    private val waitpidMethod by lazy {
        runCatching {
            android.system.Os::class.java.methods.firstOrNull { it.name == "waitpid" }
        }.getOrNull()
    }

    private fun reapZombies() {
        val method = waitpidMethod ?: return
        val paramTypes = method.parameterTypes
        val dummyStatus = if (paramTypes.size >= 2 && paramTypes[1] != Int::class.javaPrimitiveType) {
            runCatching { paramTypes[1].getDeclaredConstructor().newInstance() }.getOrNull()
        } else null

        val wnohang = 1
        while (true) {
            val res = runCatching {
                if (paramTypes.size == 3) {
                    (method.invoke(null, -1, dummyStatus, wnohang) as? Number)?.toInt() ?: 0
                } else if (paramTypes.size == 2) {
                    (method.invoke(null, -1, wnohang) as? Number)?.toInt() ?: 0
                } else 0
            }.getOrDefault(0)
            if (res <= 0) break
        }
    }
}
